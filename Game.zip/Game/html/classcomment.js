var classcomment =
[
    [ "comment", "classcomment.html#a4b0ce26e1c7cefe79707fb51995f199d", null ],
    [ "~comment", "classcomment.html#af34a387ef1189a72f5ecc3691e693716", null ],
    [ "queryComment", "classcomment.html#abe660931542b6aa380b23cd69a42db70", null ],
    [ "sendComment", "classcomment.html#a6e206e3590ef8312b90919c60619f388", null ],
    [ "sendPraise", "classcomment.html#a7076dc635f2fd2b4c5584145f82c88af", null ],
    [ "Show", "classcomment.html#a50420f46621fd199abd1990b1101afb3", null ],
    [ "showComment", "classcomment.html#ab47ea8ce30c1339dee1528391e22b9cf", null ]
];