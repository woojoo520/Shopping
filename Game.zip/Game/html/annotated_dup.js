var annotated_dup =
[
    [ "comment", "classcomment.html", "classcomment" ],
    [ "LogOn", "class_log_on.html", "class_log_on" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Message", "class_message.html", "class_message" ],
    [ "msgButton", "classmsg_button.html", "classmsg_button" ],
    [ "myButton", "classmy_button.html", "classmy_button" ],
    [ "MyDialog", "class_my_dialog.html", "class_my_dialog" ],
    [ "Mylabel", "class_mylabel.html", "class_mylabel" ],
    [ "Product", "class_product.html", "class_product" ],
    [ "productShow", "classproduct_show.html", "classproduct_show" ],
    [ "Register", "class_register.html", "class_register" ],
    [ "Release", "class_release.html", "class_release" ],
    [ "showMessage", "classshow_message.html", "classshow_message" ]
];