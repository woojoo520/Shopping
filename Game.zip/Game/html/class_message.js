var class_message =
[
    [ "Message", "class_message.html#abe50657822b329a35e36e23b31a489ca", null ],
    [ "~Message", "class_message.html#a3f7275462831f787a861271687bcad67", null ]
];