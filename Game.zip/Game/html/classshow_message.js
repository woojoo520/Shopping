var classshow_message =
[
    [ "showMessage", "classshow_message.html#ac704a6672ffffb22c27801b352a1b771", null ],
    [ "~showMessage", "classshow_message.html#a823da851c812df56ce592fc51bc34eb8", null ],
    [ "getMsgIndex", "classshow_message.html#a5aadb8728cddbaf81262a91221e0129e", null ],
    [ "readXmsg", "classshow_message.html#ade5e7ffb36366c31a5b37f9f24a97bd1", null ],
    [ "showMsg", "classshow_message.html#a190415bbc39e3afa3c76231fe000ca90", null ],
    [ "readMsg", "classshow_message.html#a0f629187ad3a9d310409714166dda775", null ],
    [ "unreadMsg", "classshow_message.html#a3b4409f101ebe26c2321b69d5bcacac1", null ]
];