var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "commentInfo", "class_main_window.html#a7b8be8328268899635acd51c57456760", null ],
    [ "connectToHost", "class_main_window.html#ac0b774192b4331f154c885c13bd23c56", null ],
    [ "queryInfo", "class_main_window.html#a1d1faa7e1d64bdedea6da9d4bbe6e388", null ],
    [ "sendData", "class_main_window.html#a538f6dbc5823a28d35b1b1186e3bc2e2", null ],
    [ "setConnaddr", "class_main_window.html#a7813699c6d3455141ee488afc7cffd04", null ],
    [ "showMsgSignal", "class_main_window.html#acf32d7580e62930fe199ffa807dfff35", null ],
    [ "showRelease", "class_main_window.html#af78d20b4ee0caf2dc8fb19c96b193b5b", null ]
];