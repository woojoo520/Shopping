var class_my_dialog =
[
    [ "MyDialog", "class_my_dialog.html#a0208e4760252b24d8acc0bc05e4acb49", null ],
    [ "~MyDialog", "class_my_dialog.html#ad48b36c2a7b088dfbe06a6a582af1bc6", null ]
];