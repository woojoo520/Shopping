var classmsg_button =
[
    [ "msgButton", "classmsg_button.html#a81f119e487c02c54e80d93e207b31678", null ],
    [ "changeIcon", "classmsg_button.html#a011ad1a1b83a1743aca2d63eabbf5ec7", null ],
    [ "readXmsg", "classmsg_button.html#a8626937f209b0ac4142abca65f8166e4", null ],
    [ "Id", "classmsg_button.html#ae1e4aa86e5792fadb2393cda06e28d20", null ]
];