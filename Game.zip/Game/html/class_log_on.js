var class_log_on =
[
    [ "LogOn", "class_log_on.html#aa5fb71157dc26e15106d252fdd6006ae", null ],
    [ "~LogOn", "class_log_on.html#a05a5d2c7e4b75873cfd45714d4099a48", null ],
    [ "logOnSucc", "class_log_on.html#adcbd6098d4c9bb33553e77e1fa174ffc", null ],
    [ "needRegister", "class_log_on.html#a66165e65c46d61a6e89d949de82ab870", null ],
    [ "sendLogOnInfo", "class_log_on.html#a7b1b6654275f7e3355b88907300636cb", null ]
];