var class_product =
[
    [ "Product", "class_product.html#a847c1d85e67ce387166a597579a55135", null ],
    [ "description", "class_product.html#a846f21736178d2ae8d96e4b5a9e33c03", null ],
    [ "price", "class_product.html#ad1fd6ee6c8653bf81898668b1d01b05d", null ],
    [ "product_id", "class_product.html#a079212e397633e0cbbc08397a461a8a6", null ],
    [ "seller_name", "class_product.html#a66839f8ab9d7cb80575a80d8d186c5c7", null ],
    [ "src", "class_product.html#a4cdf99a7b6d4b0720dca7e30dfd92693", null ],
    [ "state", "class_product.html#a6f0181d17707d769e3b42275cb622a5b", null ],
    [ "tag", "class_product.html#a518a3e5400c307c723aa5f36137361d5", null ]
];