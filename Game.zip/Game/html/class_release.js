var class_release =
[
    [ "Release", "class_release.html#a1fa4df3cda69d3a758b0b43981a3a87b", null ],
    [ "~Release", "class_release.html#ab1a1b4ee65816a9e64076851013197cd", null ],
    [ "releasePro", "class_release.html#a6df25307342ec9cf4f1847d6343e1ad8", null ],
    [ "showRelease", "class_release.html#a5292352d69deccb778918a3b2ccfea1d", null ],
    [ "fileName", "class_release.html#ac94d8e4a297ec6e47ff63c831de80259", null ],
    [ "releaseProduct", "class_release.html#a0bb10ade63681d791fa0709b8d76eb02", null ]
];