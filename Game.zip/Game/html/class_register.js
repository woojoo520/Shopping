var class_register =
[
    [ "Register", "class_register.html#a70fa8d2123b8748852d52beb94897f49", null ],
    [ "~Register", "class_register.html#a27490bda19cd4bd6ca09b48a795fc060", null ],
    [ "getInfoMation", "class_register.html#a8f72dbb7d2d3970ff81fc56f66914ad6", null ],
    [ "ImgSrcSignal", "class_register.html#ae7df43a57891cea8941bc136b620ca75", null ],
    [ "SaveImg", "class_register.html#a03167db81f66fc989bc0d64f5e5c97ac", null ],
    [ "sendInfo", "class_register.html#aba7da96d620d35a6ac88510bfcfec5dc", null ]
];