var hierarchy =
[
    [ "Product", "class_product.html", null ],
    [ "QDialog", null, [
      [ "comment", "classcomment.html", null ],
      [ "LogOn", "class_log_on.html", null ],
      [ "Message", "class_message.html", null ],
      [ "MyDialog", "class_my_dialog.html", null ],
      [ "productShow", "classproduct_show.html", null ],
      [ "Register", "class_register.html", null ],
      [ "Release", "class_release.html", null ],
      [ "showMessage", "classshow_message.html", null ]
    ] ],
    [ "QLabel", null, [
      [ "Mylabel", "class_mylabel.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QPushButton", null, [
      [ "msgButton", "classmsg_button.html", null ],
      [ "myButton", "classmy_button.html", null ]
    ] ]
];