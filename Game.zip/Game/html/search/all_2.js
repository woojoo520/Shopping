var searchData=
[
  ['filename',['fileName',['../class_release.html#ac94d8e4a297ec6e47ff63c831de80259',1,'Release']]]
];
