var searchData=
[
  ['tag',['tag',['../class_mylabel.html#a4d10bb7ba483448d1e9bef6afb3035c5',1,'Mylabel::tag()'],['../class_product.html#a518a3e5400c307c723aa5f36137361d5',1,'Product::tag()']]]
];
