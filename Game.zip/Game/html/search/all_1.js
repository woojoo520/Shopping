var searchData=
[
  ['description',['description',['../class_product.html#a846f21736178d2ae8d96e4b5a9e33c03',1,'Product']]]
];
