var searchData=
[
  ['on_5fcommentbtn_5fclicked',['on_commentBtn_clicked',['../classproduct_show.html#a7d4b4acd838bb10ab8cbf2f36e5f7c2d',1,'productShow']]]
];
