var searchData=
[
  ['connectparam',['CONNECTPARAM',['../mainwindow_8h.html#af7ca35e05556c5b1f6d870bcdd694376',1,'mainwindow.h']]]
];
