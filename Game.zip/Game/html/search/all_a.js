var searchData=
[
  ['querycomment',['queryComment',['../classcomment.html#abe660931542b6aa380b23cd69a42db70',1,'comment']]],
  ['queryinfo',['queryInfo',['../class_main_window.html#a1d1faa7e1d64bdedea6da9d4bbe6e388',1,'MainWindow']]]
];
